#include <xc.h>





// PIC16F877A Configuration Bit Settings
// 'C' source line config statements
// CONFIG
__CONFIG( FOSC_HS & WDTE_OFF & PWRTE_OFF & CP_OFF & BOREN_ON & LVP_OFF & CPD_OFF & WRT_OFF & DEBUG_OFF);        // Flash Program Memory Code Protection bit (Code protection off)

#include <xc.h>
// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
 char num15=21;
 char num20=32;
 char num3=3;
 char M=0;
#define _XTAL_FREQ 20000000 
void main(void) {
  
    TRISC=0xff;
    TRISB=0x0; 
    TRISD=0X0;
    RD0=0;RD1=0;RD2=0;RD3=0;RD4=0;RD5=0;RD6=0;RD7=1;
  
 
    while(RC0==1 && RC1==0){ //RC0==STTART
        RD7=0;
        
       for(char i=0 ;i<=15;i++) { RD3=1;
                                if(i<13){RD2=1;}else RD2=0;
                                if(i>=13){RD0=1;}else RD0=0;
                                if(RC1==1){RD7=1;break;} ; PORTB=num15;  num15--;  __delay_ms(200); if(num15==15){  num15-=6;}; }  RD3=0;    num15=21; 
for(char j=0 ; j<=3;j++) { RD4=1; if(RC1==1){RD7=1;break;};  PORTB=num3;   num3--;   __delay_ms(200);}  RD4=0;           num3=3; 
for(char k=0;k <=20;k++) { RD5=1; if(k>17){RD0=0;RD1=1;}; if(RC1==1){RD7=1;break;};  PORTB=num20;    __delay_ms(200); num20--; if(num20==31 || num20==15){ num20-=6;}  }RD5=0;RD1=0; num20=32;
       }
    while(RC1==1){
               if(RC2==1){M++;}
        if (M>1)M=0;   
               if (M==0){RD0=1; RD3=0;
                     RD2=0; RD5=1;
                     RD1=0; RD4=0;__delay_ms(80);}
       
        if (M==1){ RD0=0; RD3=1;
                   RD2=1; RD5=0;
                   RD1=0; RD4=0;
                  __delay_ms(80); }
        
    }
    
}


